from tensorflow.keras.models import model_from_json
import tensorflow as tf
import base64
import io
from PIL import Image
import cv2


def init():
    # Загружаем топологию модели
    json_file = open('model.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    global loaded_model, graph
    loaded_model = model_from_json(loaded_model_json)
    # Загружаем веса модели
    loaded_model.load_weights("model.h5")
    print("Loaded model from disk")
    # Компиляция модели
    loaded_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    graph = tf.get_default_graph()


def predict(some_json):
    # Декодируем входные данные
    my_image = base64.decodestring(str(some_json['params'][0]['image']).encode())
    image = Image.open(io.BytesIO(my_image))
    image.save('/data/im.jpg')
    my_image = cv2.imread("/data/im.jpg")
    my_image = cv2.resize(my_image, (50, 50))
    my_image = my_image.reshape(1, 50, 50, 3)
    res = 0
    with graph.as_default():
        res = loaded_model.predict(my_image)[0][0] == 1.0
    if (res == 1.0):
        return 'dog'
    else:
        return 'cat'



